      .cpu cortex-m4
      .thumb
      .syntax unified
      .text
      .globl main
      .thumb_func
main: MOVS.N R0, #70
      MOVS.N R1, #130
      LDR.N  R2, =gcd_c
      BLX.N  R2
      MOVS.N R4, R0
      MOVS.N R0, #70
      MOVS.N R1, #130
      LDR.N  R2, =gcd
      BLX.N  R2
      MOVS.N R5, R0
      CMP.N  R4, R5
error:
      BNE.N  error
ok:
      B.N    ok
