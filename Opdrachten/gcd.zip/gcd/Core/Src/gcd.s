      .cpu cortex-m4
      .thumb
      .syntax unified
      .text
      .globl gcd
      .thumb_func
gcd:  CMP.N  R0, R1
      BEQ.N  end
      BLS.N  else
      SUBS.N R0, R0, R1
      B.N    gcd
else: SUBS.N R1, R1, R0
      B.N    gcd
end:  BX.N   LR
