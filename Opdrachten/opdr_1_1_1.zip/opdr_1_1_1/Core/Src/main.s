  .syntax unified
  .cpu cortex-m4
  .thumb
  .text
  .global main
main:
		B.N		main
